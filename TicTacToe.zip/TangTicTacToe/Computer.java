
/**
 * The computer class analyzes the board to determine where the computer can move to make three in a row, block the player, make two in a
 * row, or make a random move. It also analyzes whether the game has been won by any move.
 * @author Teresa Tang
 * @version 5/13/2019
 */
public class Computer
{
    //the computer has access to the game board and X and O values
    private int [] board;
    private int OValue; 
    private int XValue; 
    
    /**
     * Constructor for objects of class Computer
     */
    public Computer(int [] gameBoard, int OValue, int XValue)
    {
        this.board = gameBoard; 
        this.OValue = OValue; 
        this.XValue = XValue; 
    }
    
    /**
     * Determines if the game has been won by summing each row, column, and diagonal 
     *
     * @param     none
     * @return    if game has been won
     */
    public boolean isGameWon() {
         //parse all rows
        for(int rowStart = 1; rowStart <= 7; rowStart += 3) {
            if(sumRow(rowStart) == 3*XValue ||sumRow(rowStart) == 3*OValue) {
                return true; 
            }
        }
        //parse all columns 
        for(int colStart = 1; colStart <= 3; colStart++) {
            if(sumCol(colStart) == 3*XValue || sumCol(colStart) == 3*OValue) {
                return true; 
            }
        }
       
        //parse both diagonals
        for(int diagStart = 1; diagStart <= 3; diagStart += 2) {
            if(sumDiag(diagStart) == 3*XValue || sumDiag(diagStart) == 3*OValue ) {
                return true; 
            }
        }
        
        //The game has not been won
        return false; 
    }
    
    /**
     * Computer finds the empty box in the given row 
     *
     * @param  row starting box (either box 1, 4, or 7) 
     * @return  empty box number
     */
    public int emptyInRow(int rowStart) {
        for(int idx = 0; idx < 3; idx++) {
            if(isEmpty(rowStart - 1 + idx)) {
                return rowStart + idx; 
            }
        }
        return 0; 
    }
    
    /**
     * Computer calculates the sum of the given row 
     *
     * @param  row starting box (either box 1, 4, or 7) 
     * @return  sum
     */
    public int sumRow(int rowStart) {
        int sum = 0; 
        for(int idx = 0; idx < 3; idx++) {
            sum = sum + this.board[rowStart - 1 + idx]; 
        }
        return sum; 
    }
    
    /**
     * Computer finds the empty space in the given column
     *
     * @param  column starting box (either box 1, 2, or 3)
     * @return  box number with empty space
     */
    public int emptyInCol(int colStart) {
        for(int idx = 0; idx < 3; idx++) {
            if(isEmpty(colStart - 1 + (idx*3))) {
                return colStart + (idx*3); 
            } 
        }
        return 0; 
    }
    
    /**
     * Computer calculates the sum of the given column
     *
     * @param  column starting box (either box 1, 2, or 3)
     * @return  sum
     */
    public int sumCol(int colStart) {
        int sum = 0; 
        for(int idx = 0; idx < 3; idx++) {
            sum = sum + this.board[colStart - 1 + (idx*3)]; 
        }
        return sum; 
    }
    
    /**
     * Computer finds the empty space in the given diagonal
     *
     * @param  diagonal starting box (either box 1 for this diagonal: \ or box 3 for this diagonal: /) 
     * @return  sum
     */
    public int emptyInDiag(int diagStart) {
        //step is the amount added to the previous box's index to reach the next box's index
        //in the diagonal
        int step = 0; 
        if(diagStart == 1) {
            step = 4; 
        } else {
            step = 2; 
        }
        
        for(int idx = 0; idx < 3; idx++) {
            if(isEmpty(diagStart - 1 + (idx*step))) {
                //If empty, return the box number
                return diagStart + (idx*step); 
            }
        }
        //No empty space found
        return 0;
    }
    
    /**
     * Computer calculates the sum of the given diagonal
     *
     * @param  diagonal starting box (either box 1 for this diagonal: \ or box 3 for this diagonal: /) 
     * @return  sum
     */
    public int sumDiag(int diagStart) {
        int sum = 0; 
        //step is the amount added to the previous box's index to reach the next box's index
        //in the diagonal
        int step = 0; 
        if(diagStart == 1) {
            step = 4; 
        } else {
            step = 2; 
        }
        
        for(int idx = 0; idx < 3; idx++) {
            sum = sum + this.board[diagStart - 1 + (idx*step)]; 
        }
        return sum;
    }
    
    /**
     * Sums all rows, columns, and diagonals to see if any equals a certain amount
     *
     * @param  the amount that the sum should equal 
     * @return  the box the computer can move in  
     */
    public int sumAll(int amount)
    { 
        //parse all rows
        for(int rowStart = 1; rowStart <= 7; rowStart += 3) {
            if(sumRow(rowStart) == amount) {
                //find the empty space in the given row 
                return emptyInRow(rowStart); 
            }
        }
        //parse all columns 
        for(int colStart = 1; colStart <= 3; colStart++) {
            if(sumCol(colStart) == amount) {
                 //find the empty space in the given column
                return emptyInCol(colStart); 
            }
        }
       
        //parse both diagonals
        for(int diagStart = 1; diagStart <= 3; diagStart += 2) {
            if(sumDiag(diagStart) == amount) {
                //find the empty space in the given diagonal
                return emptyInDiag(diagStart); 
            }
        }
        
        //sum not found
        //return a box of 0
        return 0; 
    }
    
    /**
     * Determines if the given array space is empty 
     *
     * @param array index of interest
     * @return none
     */
    public boolean isEmpty(int idx) {
        if (this.board[idx] == 0) {
            //an empty box has a value of 0
            return true; 
        } else {
            return false; 
        }
    }
    
     /**
     * Choose a random location to move in 
     *
     * @param  number of moves on the board
     * @return  number of box in which to move
     */
    public int randomMove(int numMoves)
    { 
        //find the last empty space on the board
        if(numMoves == 9) {
            for(int i = 0; i < 9; i++) {
                if(isEmpty(i)) {
                    //return box number of empty box 
                    return i + 1; 
                }
            }
        } 
        
        //chooses a random space out of the remaining empty spaces
        int value = (int) (Math.random() * 8); 
        while(!isEmpty(value)) {
            //if box isn't empty, find a new random box 
            value = (int) (Math.random() * 8);
        }
        return value + 1; 
    }
    
    /**
     * Actions performed during the computer's turn
     *
     * @param  updated board and number of moves on the board
     * @return  number of box in which to move
     */
    public int turn(int [] updatedBoard, int numMoves)
    { 
        this.board = updatedBoard; 
   
        //If the sum of a row, column, or diagonal is 2*OValue, then that means there are 2 O's in a row
        //sumAll returns the box that the computer can move in to make 3 O's in arow 
        int box = sumAll(2*this.OValue); 
        
        if(box == 0) {
            //This means the computer cannot make 3 O's in a row
            //The computer now tries to find a row, column, or diagonal with two X's
            //To block the player
            box = sumAll(2*this.XValue); 
        } else {
            //The computer can make three in a row
            //Return location to make three in a row
            return box; 
        }
        
        if(box == 0) {
            //The player cannot be blocked
            //The computer now tries to find a row, column, or diagonal with one O
            //So that the computer can make two O's in a row
            box = sumAll(this.OValue); 
        
        } else {
            //The player can be blocked
            //Return the box that the computer can move in to block the player
            return box; 
        }
        
        if(box == 0) {
            //This means the computer cannot make two O's in a row
            //The computer now makes a random move 
            box = randomMove(numMoves); 
        } else {
            //Return location to make two in a row
            return box; 
        }    
        //Return location of random move 
        return box; 
    }
}
