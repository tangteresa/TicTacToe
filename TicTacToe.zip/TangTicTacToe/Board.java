
/**
 * The board class mainpulates the tic tac toe board by adding moves or printing the board to the console. The tic tac toe board 
 * may contain X's and O's or the numbering of each box (for player instructional purposes). 
 *
 * @author Teresa Tang
 * @version 5/13/2019
 */
public class Board
{
    //represent a tic tac toe board as a 1D array of 9 spots/boxes
    private int [] board;
    final int XValue; 
    final int OValue; 
    /**
     * Constructor for objects of class Board
     */
    public Board(int XValue, int OValue)
    {
        board = new int [9]; 
        this.XValue = XValue; 
        this.OValue = OValue; 
    }
    /**
     * Sets the game board to a new blank board
     *
     * @param new board
     * @return none
     */
    public void setBoard(int [] newBoard) {
        this.board = newBoard; 
    }
    
     /**
     * Returns the game board 
     *
     * @param none
     * @return game board
     */
    public int [] getBoard() {
        return board; 
    }
    
     /**
     * Determines if the given box is empty 
     *
     * @param int box (box number of interest)
     * @return none
     */
    public boolean isEmpty(int box) {
        //empty boxes have an integer value of 0
        if (board[box-1] == 0) {
            return true; 
        } else {
            return false; 
        }
    }
    
    /**
     * Add a move (an O or an X in integer form) to the board
     *
     * @param  int markValue (the value of an O or X in integer form)
     * @param int box (box number to move in)
     * @return updated board
     */
    public int [] addMark(int markValue, int box) {
        this.board[box-1] = markValue; 
        return this.board; 
    }
    
    /**
     * Convert the board integer array to a board with X's and O's 
     *
     * @param  none
     * @return none
     */
    public void printInMarks() {
        //Prints the board with X's and O's 
        int idx = 0; 
        for(int row = 0; row < 3; ++row) {
            for (int col = 0; col < 3; ++col) {
                
                //Print X
                if (board[idx] == XValue) {
                    System.out.print("X"); 
                } else if (board[idx] == OValue) {
                    //Print O
                    System.out.print("O"); 
                } else {
                    //Print space 
                    System.out.print(" "); 
                }
                
                if(col != 2) {
                    if(col == 1) {
                       System.out.print("|"); 
                    } else {
                       System.out.print("|");  
                    }
                }  
                idx++;   
            }
            
            if (row != 2) {
                System.out.print("\n");
                System.out.println("_|_|_"); 
            }
        }
        //Print two extra blank lines for aethestics
        System.out.print("\n");
        System.out.print("\n");
    }
    /**
     * Print the game instructions and a board with number labels for each square
     *
     * @param  none
     * @return none
     */
    public void printInstructions()
    {
        System.out.println("Each box on the tic tac toe board has a number."); 
        
        //Prints the board with numbers 
        int num = 1; 
        for(int row = 0; row < 3; ++row) {
            for (int col = 0; col < 3; ++col) {
                System.out.print(num); 
                if(col != 2) {
                    if(col == 1) {
                       System.out.print("|"); 
                    } else {
                       System.out.print("|");  
                    }
                }  
                num++;   
            }
            
            if (row != 2) {
                System.out.print("\n");
                System.out.println("_|_|_"); 
            }
        }
        //Print two extra blank lines for aethestics
        System.out.print("\n");
        System.out.print("\n");
    }
}
