
/**
 * The game class is the "heartbeat" of the game. It runs the tic tac toe game, alternates between the 
 * computer and player's turns, and analyzes user input for which box the player wants to move in and 
 * whether or not the game should be restarted (determined by whether someone has won or if the player 
 * wants to restart). 
 * @author Teresa Tang (tangsteresa@gmail.com)
 * @version 5/13/2019
 */

import java.util.Scanner;

public class Game
{
    //whether or not it is the player's turn
    private boolean isPlayersTurn; 
    //whether or not game is running
    private boolean running; 
    //total moves on the board
    private int numMoves; 
    //value of an X as an integer
    private final int XValue;
    //value of an O as an integer
    private final int OValue; 
    
    //the game has a game board and an opponent (a computer)
    private Board gameBoard; 
    private Computer opponent; 
    
    /**
     * Constructor for the Game class
     */
    public Game()
    {
        isPlayersTurn = true; 
        running = true; 
        numMoves = 0; 
        OValue = 1; 
        
        //30 is an arbitrary multiplier to guarantee that XValue 
        //is signifcantly larger than OValue 
        XValue = OValue * 30;
        gameBoard = new Board(XValue, OValue); 
        opponent = new Computer(gameBoard.getBoard(), OValue, XValue); 
        
    }
    
    /**
     * Runs the tic tac toe game 
     *
     * @param     none
     * @return    none
     */
    public void runGame() {
          //while game is running (i.e. while no one has won or 
          //the player has restarted), alternate between player and computer's turns 
          while(running) {
              //game beginning 
              System.out.println("Let's play Tic Tac Toe! You are X."); 
              gameBoard.printInstructions(); 
          
              //gameOver tracks if game has been won or is a cat game
              boolean gameOver = false; 
              //Reset number of moves to 0
              numMoves = 0; 
              
              //alternate between player and computer
              while(!gameOver) {
                  if(isPlayersTurn) {
                      //player's turn
                      System.out.println("Your turn!"); 
                      numMoves++; 
                      playersTurn(); 
                                           
                      isPlayersTurn = false; 
                      //print game board 
                      gameBoard.printInMarks();

                  } else {
                      //computer's turn
                      System.out.println("Computer's turn!");
                      numMoves++; 
                      //update the computer's board version and add the computer's move to the board
                      gameBoard.setBoard(gameBoard.addMark(OValue,opponent.turn(gameBoard.getBoard(), numMoves))); 
                      
                      isPlayersTurn =true;
                      //print game board 
                      gameBoard.printInMarks();
                  } 
                  gameOver = isGameOver();  
              }
              //ask if player wants to restart 
              restart(); 
          }
    }
    
    /**
     * Determines if the game is over (if the board is full or game is won) 
     *
     * @param     none
     * @return    wehther or not game is over
     */
    public boolean isGameOver() {
        boolean full = fullBoard(); 
        boolean gameWon = false; 
        
        //If there are at least 3 pieces on the board, check if game is won
        if(numMoves >= 3) {
            gameWon = opponent.isGameWon(); 
        } 
        
        if(gameWon) {
            if(isPlayersTurn) {
                //if it is player's turn, then the computer must have won
                System.out.println("The computer has won! Sorry."); 
                return true;
            } else {
                //player won
                System.out.println("You win!"); 
                return true; 
            }
        } else if (full) {
            //if the board is full and the game wasn't won, it is a cat game
            System.out.println("Cat game!"); 
            return true; 
        } else {
            //Do nothing 
        }  
        return false; 
    }
    
    /**
     * Determines if the board is full 
     *
     * @param     none
     * @return    whether or not board is full
     */
    public boolean fullBoard() {
        if(numMoves == 9) {
            return true; 
        } else {
            return false; 
        }
    }
    
    /**
     * Actions that the player performs on their turn
     *
     * @param     none
     * @return    none
     */
    public void playersTurn() {
        //read user input 
        int move = readNumericalInput(); 
        
        while(!gameBoard.isEmpty(move)) {
            //If chosen box isn't empty, try again 
            System.out.println("This space is not empty. Please try again."); 
            move = readNumericalInput(); 
        }
        //if chosen box is empty, add move to the board 
        gameBoard.setBoard(gameBoard.addMark(XValue, move)); 

    }
    
  
    /**
     * Asks player if they would like to restart
     *
     * @param     none
     * @return    none
     */
    public void restart() {
       //Create scanner and take in user String input 
       Scanner reader = new Scanner(System.in);  
       //Tracks if input is a valid integer 
       boolean goodInput = false; 
       //Saves the numerical value of the input 
       String answer = "";
       while(!goodInput) {
           System.out.println("Would you like to restart? Type y for yes and n for no."); 
           answer = reader.nextLine();  
           
           if(answer.equals("n") || answer.equals("N")) {
               //stop the game 
               running = false; 
               goodInput = true; 
           } else if (answer.equals("y") || answer.equals("Y")) {
               //game continues to run
               goodInput = true; 
               //reset array board to all zero's
               gameBoard.setBoard(new int [9]); 
           } else {
               //not acceptable input
               System.out.println("Invalid input. Please try again."); 
           }
            
       }
       reader.close();

    }
    
    /**
     * Reads player's input of the number of the box they want to move in 
     *
     * @param     none
     * @return    integer value of user input
     */
    public int readNumericalInput() {
       //Create scanner and take in user input 
       Scanner reader = new Scanner(System.in);  
       //Tracks if input is a valid integer 
       boolean goodInput = false; 
       //Saves the numerical value of the input 
       int value = 0;
       while(!goodInput) {
           System.out.println("Type the box number you want to move in:"); 
           String input = reader.nextLine();  
           try {
               value = Integer.parseInt(input);
           }
           catch (NumberFormatException e)
           {
               //Do nothing
           }
            
           if(value >= 1 && value <= 9) {
               //Input is acceptable
               goodInput = true; 
           } else {
               System.out.println("Invalid input. Please try again."); 
           }
       }
       reader.close();
       return value; 

    }
    
    //main 
     public static void main (String args [ ])  {
        //create a tic tac toe game
        Game game = new Game(); 
        
        //run game
        game.runGame(); 
        
    }

}
